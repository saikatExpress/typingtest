$(document).ready(function() {
    setTimeout(function() {
        $('#success-message').fadeOut('slow');
    }, 2000);

    setTimeout(function() {
        $('#error-message').fadeOut('slow');
    }, 2000);
});
